<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }

  $id = $_GET['index'];

  if (isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $role = $_POST['role'];

    $sql = "UPDATE users SET first_name='$first_name', last_name='$last_name', role='$role' WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
      $msg = "<div class='alert alert-success'>User Updated Successfull.</div>";
    }else {
      echo "Error: " . $sql . mysqli_error($conn);
    }
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Edit User</h1>
    <?php if (isset($_POST['submit'])) { echo $msg; } ?>

    <?php
      $sql = "SELECT * FROM users WHERE id='$id'";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    ?>
    <form class="form" action="" method="post">
      <div class="row">
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="first_name" class="form-control" placeholder="First Name" value="<?php echo $row['first_name']; ?>" required>
        </div>
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo $row['last_name']; ?>" required>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-sm-12 mb-2">
          <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo $row['email']; ?>" disabled>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-sm-12 mb-2">
          <select class="form-control" name="role" required>
            <option value="" selected disabled>Select Role</option>
            <?php if ($row['role'] == 1): ?>
              <option value="1" selected>Admin</option>
              <option value="0">User</option>
            <?php endif; ?>
            <?php if ($row['role'] == 0): ?>
              <option value="1">Admin</option>
              <option value="0" selected>User</option>
            <?php endif; ?>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <button type="submit" name="submit" class="btn btn-primary">Update User</button>
        </div>
      </div>
    </form>
  <?php } ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>
