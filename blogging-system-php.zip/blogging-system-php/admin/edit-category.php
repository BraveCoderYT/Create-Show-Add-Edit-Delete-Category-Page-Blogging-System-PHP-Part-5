<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }

  $id = $_GET['index'];

  if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM categories WHERE id='$id'")) == 0) {
    echo "<script>window.location.replace('categories.php');</script>";
  }else {
    if (isset($_POST['submit'])) {
      $cat_name = $_POST['cat_name'];
      $cat_order = $_POST['cat_order'];

      $sql = "UPDATE categories SET cat_name='$cat_name', cat_order='$cat_order' WHERE id='$id'";
      $result = mysqli_query($conn, $sql);

      if ($result) {
        $msg = "<div class='alert alert-success'>{$cat_name} - This category has been updated.</div>";
      }else {
        echo "Error: " . $sql . mysqli_error($conn);
      }
    }
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Edit Category</h1>
    <?php
      if (isset($_POST['submit'])) { echo $msg; }

      $sql = "SELECT * FROM categories WHERE id='$id'";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result)) {
        $row = mysqli_fetch_assoc($result);
    ?>

    <form class="form" action="" method="post">
      <div class="row">
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="cat_name" class="form-control" placeholder="Category Name" value="<?php echo $row['cat_name']; ?>" required>
        </div>
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="number" name="cat_order" class="form-control" placeholder="Category Order" value="<?php echo $row['cat_order']; ?>" required>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <button type="submit" name="submit" class="btn btn-primary">Update Category</button>
        </div>
      </div>
    </form>
    <?php } ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>
