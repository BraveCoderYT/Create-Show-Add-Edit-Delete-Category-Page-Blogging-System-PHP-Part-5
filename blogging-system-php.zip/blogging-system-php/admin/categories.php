<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Categories</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Categories</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
              <?php
                $sql = "SELECT * FROM categories";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
              ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Category Name</th>
                            <th>Category Order</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                          <th>Id</th>
                          <th>Category Name</th>
                          <th>Category Order</th>
                          <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                      <?php $cat_id = 0; while ($row = mysqli_fetch_assoc($result)) { $cat_id++ ?>
                        <tr>
                            <td><?php echo $cat_id; ?></td>
                            <td><?php echo $row['cat_name']; ?></td>
                            <td><?php echo $row['cat_order']; ?></td>
                            <td>
                              <a href="edit-category.php?index=<?php echo $row['id']; ?>">Edit</a>
                              <a href="delete-category.php?index=<?php echo $row['id']; ?>" class="text-danger ml-1">Delete</a>
                            </td>
                        </tr>
                      <?php } ?>
                    </tbody>
                </table>
              <?php } ?>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>

<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>
