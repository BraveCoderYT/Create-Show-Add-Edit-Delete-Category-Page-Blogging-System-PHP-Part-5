<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }

  if (isset($_POST['submit'])) {
    $cat_name = $_POST['cat_name'];
    $cat_order = $_POST['cat_order'];

    if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM categories WHERE cat_order='$cat_order'")) > 0) {
      $msg = "<div class='alert alert-warning'>{$cat_order} - This order has already been added.</div>";
    }else {
      $sql = "INSERT INTO categories (cat_name, cat_order) VALUES ('$cat_name', '$cat_order')";
      $result = mysqli_query($conn, $sql);

      if ($result) {
        $msg = "<div class='alert alert-success'>A new category has been added.</div>";
      }else {
        echo "Error: " . $sql . mysqli_error($conn);
      }
    }
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Add Category</h1>
    <?php if (isset($_POST['submit'])) { echo $msg; } ?>

    <form class="form" action="" method="post">
      <div class="row">
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="cat_name" class="form-control" placeholder="Category Name" required>
        </div>
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="number" name="cat_order" class="form-control" placeholder="Category Order" required>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <button type="submit" name="submit" class="btn btn-primary">Add Category</button>
        </div>
      </div>
    </form>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>
