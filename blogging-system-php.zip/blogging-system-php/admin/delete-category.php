<?php
  session_start();
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }else{
    include '../install/config.php';

    $id = $_GET['index'];

    if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM categories WHERE id='$id'")) == 0) {
      header("Location: categories.php");
    }else {
      $sql = "DELETE FROM categories WHERE id='$id'";
      $result = mysqli_query($conn, $sql);

      if ($result) {
        header("Location: categories.php");
      }else {
        echo "Error: " . $sql . mysqli_error($conn);
      }
    }
  }
?>
