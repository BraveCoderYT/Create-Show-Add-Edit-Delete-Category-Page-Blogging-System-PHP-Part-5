<?php
  session_start();
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }else {
    include '../install/config.php';

    $id = $_GET['index'];

    $sql = "DELETE FROM users WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
      header("Location: users.php");
    }else {
      echo "Error: " . $sql . mysqli_error($conn);
    }
  }
?>
